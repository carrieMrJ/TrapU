package nowhere2gopp.preset;

public interface Requestable {
    Move request() throws Exception;
}
