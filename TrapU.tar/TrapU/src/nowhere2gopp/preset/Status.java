package nowhere2gopp.preset;

import java.io.Serializable;

public enum Status implements Serializable {
    Ok,
    RedWin,
    BlueWin,
    Draw,
    Illegal
}
