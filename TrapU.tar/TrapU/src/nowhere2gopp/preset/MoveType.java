package nowhere2gopp.preset;

import java.io.Serializable;

public enum MoveType implements Serializable {
    AgentLink,
    LinkLink,
    Surrender,
    End
}
