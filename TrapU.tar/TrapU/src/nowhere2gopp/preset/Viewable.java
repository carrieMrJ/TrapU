package nowhere2gopp.preset;

public interface Viewable {
    Viewer viewer();
}
