package nowhere2gopp.preset;

public enum PlayerType {
    Human,
    RandomAI,
    SimpleAI,
    ExtendedAI,
    UpgradedAI,
    EnhancedAI,
    AdvancedAI,
    Remote
}
